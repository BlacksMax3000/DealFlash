"""Almacenamiento persistente."""
